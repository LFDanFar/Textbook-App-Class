package com.example.lab1

import androidx.lifecycle.ViewModel

class CheatViewModel: ViewModel() {

    var answerShown = false
}